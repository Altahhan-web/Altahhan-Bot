const settings = {
  packname: 'الطحان بوت',
  author: '‎',
  botName: "الطحان بوت",
  botOwner: 'الطحان بوت', // Your name
  ownerNumber: '', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "الطحان بوت - WhatsApp Bot",
  version: "3.0.4",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
